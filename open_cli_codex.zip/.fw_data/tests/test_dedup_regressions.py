#!/usr/bin/env python3
"""Focused regression tests for runtime/history dedup behavior."""

import importlib.util
import json
from pathlib import Path


ROOT = Path(__file__).resolve().parents[2]
SPEC = importlib.util.spec_from_file_location("fw_loader", ROOT / "fw.py")
FW = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(FW)
NS = {"__name__": "_fw_dedup_test", "__file__": str(ROOT / "fw.py")}
FW._load_modules(NS)


def tool_call(call_id, name, args):
    return {
        "id": call_id,
        "type": "function",
        "function": {"name": name, "arguments": json.dumps(args)},
    }


def group(call_id, name, args, content):
    return [
        {"role": "assistant", "content": None,
         "tool_calls": [tool_call(call_id, name, args)]},
        {"role": "tool", "tool_call_id": call_id, "content": content},
    ]


def test_mutation_classification():
    mutate = NS["_tool_may_mutate_state"]
    local = NS["_tool_may_mutate_local_files"]

    for name in ("write", "delete", "extract", "edit", "multiedit", "apply_patch"):
        assert mutate(name, {})
        assert local(name, {})

    assert not mutate("view_symbol", {"path": "a.py", "symbol": "A"})
    assert not mutate("bash", {"command": "rg TODO ."})
    assert not mutate("bash", {"command": "stat a.py"})
    assert mutate("bash", {"command": "python script.py"})
    assert mutate("mcp__github__update_issue", {})
    assert mutate("mcp__github__createIssue", {})
    assert not mutate("mcp__github__list_issues", {})


def test_dynamic_tools_are_not_hard_blocked():
    should_block = NS["_dedup_should_block"]
    for name in ("question", "verify", "webfetch", "websearch", "task", "todowrite"):
        assert not should_block(name)
    assert not should_block("mcp__github__list_issues")
    assert should_block("mcp__github__create_issue")
    assert should_block("read")
    assert should_block("apply_patch")
    blocked = NS["_tool_was_definitely_blocked"]
    assert blocked("[permission denied: apply_patch]")
    assert blocked("[policy] bash command blocked by allowlist")
    assert not blocked("[error: patch failed after execution started]")


def test_history_key_keeps_distinct_evidence():
    key = NS["_history_tool_call_key"]
    assert key("read", {"path": "a.py"}) == key(
        "read", {"path": "a.py", "offset": 1, "limit": 80, "depth": 4})
    assert key("read", {"path": "a.py", "offset": 1, "limit": 60}) != key(
        "read", {"path": "a.py", "offset": 500, "limit": 60})
    assert key("grep", {"path": "a.py", "pattern": "TODO"}) != key(
        "grep", {"path": "a.py", "pattern": "security"})
    assert key("view_symbol", {"path": "a.py", "symbol": "A"}) != key(
        "view_symbol", {"path": "a.py", "symbol": "B"})


def test_mutation_epoch_allows_same_read_after_patch():
    mutate = NS["_tool_may_mutate_state"]
    epoch = 0
    read_sig_epoch = epoch
    if mutate("apply_patch", {"path": "a.py", "patch": "@@"}):
        epoch += 1
    assert read_sig_epoch != epoch

    signature = NS["_runtime_tool_call_signature"]
    assert signature("extract", {"src": "a", "start": 1, "end": 2, "dst": "b"}) == signature(
        "extract", {"src": "a", "start": 1, "end": 2, "dst": "b", "mode": "move"})


def test_prune_only_dedups_exact_queries():
    prune = NS["_prune_tool_results"]
    long_a = "A" * 7000
    long_b = "B" * 7000
    messages = []
    messages += group("r1", "read", {"path": "a.py", "offset": 1, "limit": 60}, long_a)
    messages += group("r2", "read", {"path": "a.py", "offset": 500, "limit": 60}, long_b)
    distinct = prune(messages, keep_full_turns=10)
    assert distinct[1]["content"] == long_a
    assert distinct[3]["content"] == long_b

    messages += group("r3", "read", {"path": "a.py", "offset": 1, "limit": 60}, long_a)
    deduped = prune(messages, keep_full_turns=10)
    assert len(deduped[1]["content"]) < len(long_a)
    assert deduped[3]["content"] == long_b
    assert deduped[5]["content"] == long_a


def test_subagent_style_prune_keeps_latest_patch_only():
    prune = NS["_prune_tool_results"]
    marker = NS["_HISTORY_COMPACTED_MARKER"]
    old_patch = "x" * 5000
    new_patch = "y" * 5000
    messages = []
    messages += group("p1", "apply_patch", {"path": "a.py", "patch": old_patch}, "ok")
    messages += group("p2", "apply_patch", {"path": "a.py", "patch": new_patch}, "ok")
    result = prune(messages, keep_full_turns=1)
    old_args = json.loads(result[0]["tool_calls"][0]["function"]["arguments"])
    new_args = json.loads(result[2]["tool_calls"][0]["function"]["arguments"])
    assert old_args["patch"] == marker
    assert new_args["patch"] == new_patch


def main():
    tests = [value for name, value in globals().items() if name.startswith("test_")]
    for test in tests:
        test()
    print(f"dedup regression tests: {len(tests)} passed")


if __name__ == "__main__":
    main()
