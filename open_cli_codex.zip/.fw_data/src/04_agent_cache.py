# ── Agent modes ──────────────────────────────────────────────────────────────
AGENT_BUILD = "build"   # full access
AGENT_PLAN  = "plan"    # read-only

# ── Permission levels ────────────────────────────────────────────────────────
PERM_ALLOW = "allow"
PERM_ASK   = "ask"
PERM_DENY  = "deny"

# Default permissions per tool
DEFAULT_PERMS = {
    "bash":        PERM_ASK,    # dangerous — ask by default
    "write":       PERM_ALLOW,
    "delete":      PERM_ALLOW,  # undo-stack bảo vệ giống write/edit
    "extract":     PERM_ALLOW,
    "edit":        PERM_ALLOW,
    "apply_patch": PERM_ALLOW,
    "read":        PERM_ALLOW,
    "glob":        PERM_ALLOW,
    "grep":        PERM_ALLOW,
    "webfetch":    PERM_ALLOW,
    "websearch":   PERM_ALLOW,
    "todowrite":   PERM_ALLOW,
    "todoread":    PERM_ALLOW,
    "question":    PERM_ALLOW,
    "task":        PERM_ALLOW,
    "delegate":    PERM_ALLOW,
    "skill":       PERM_ALLOW,
    "lsp":         PERM_ALLOW,
}

# Plan-mode overrides (read-only)
PLAN_PERMS = {
    "bash":        PERM_DENY,
    "write":       PERM_DENY,
    "delete":      PERM_DENY,
    "extract":     PERM_DENY,
    "edit":        PERM_DENY,
    "apply_patch": PERM_DENY,
}

# Skills search paths
SKILLS_DIRS = [
    Path.cwd() / FW_DATA_NAME / "skills",      # project-local (chính)
    Path.cwd() / ".opencode" / "skills",        # opencode compat
]


# AGENTS.md / rules search paths (opencode compatible)
AGENTS_FILES = [
    Path.cwd() / "AGENTS.md",
    Path.cwd() / "CLAUDE.md",              # claude-code compat
    Path.home() / ".config" / "opencode" / "AGENTS.md",
    Path.cwd() / FW_DATA_NAME / "AGENTS.md",  # fw project-local
    Path.home() / ".claude" / "CLAUDE.md", # claude-code global compat
]

# Cache AGENTS.md: key=(path, mtime) → tránh đọc file mỗi turn
_agents_cache: dict = {}   # path_str → (mtime, text)
_agents_combined_cache: tuple = (None, "")  # (fingerprint, combined_text)

def load_agents_md(extra_dirs: list[Path] | None = None) -> str:
    """Load AGENTS.md / rules files, cache theo mtime để không đọc lại mỗi turn."""
    global _agents_combined_cache

    def _read_cached(p: Path) -> str:
        """Đọc file, cache theo mtime. Trả về "" nếu không đổi."""
        try:
            mtime = p.stat().st_mtime
        except Exception:
            return ""
        key = str(p)
        cached = _agents_cache.get(key)
        if cached and cached[0] == mtime:
            return cached[1]
        try:
            text = p.read_text().strip()
            _agents_cache[key] = (mtime, text)
            return text
        except Exception:
            return ""

    found = []
    # project-level: traverse up từ cwd
    cwd = Path.cwd()
    for parent in [cwd, *cwd.parents]:
        for name in ("AGENTS.md", "CLAUDE.md"):
            p = parent / name
            if p.exists():
                text = _read_cached(p)
                if text:
                    found.append(f"# Rules from {p}\n\n{text}")
                break
        if found:
            break
    # global
    for gp in [
        Path.home() / ".config" / "opencode" / "AGENTS.md",
        Path.cwd() / FW_DATA_NAME / "AGENTS.md",
        Path.home() / ".claude" / "CLAUDE.md",
    ]:
        if gp.exists():
            text = _read_cached(gp)
            if text:
                found.append(f"# Global rules from {gp}\n\n{text}")
            break
    return "\n\n".join(found) if found else ""

# Custom commands: loaded from .fw_data/commands/*.md và .opencode/commands/*.md
COMMANDS_DIRS = [
    Path.cwd() / FW_DATA_NAME / "commands",    # project-local (chính)
    Path.cwd() / ".opencode" / "commands",      # opencode compat
    Path.home() / ".config" / "opencode" / "commands",
]

def load_custom_commands() -> dict:
    """
    Load custom slash commands from .opencode/commands/*.md
    Returns {name: {template, description, agent, model, subtask}}
    """
    commands = {}
    for cmd_dir in COMMANDS_DIRS:
        if not cmd_dir.exists():
            continue
        for f in sorted(cmd_dir.glob("*.md")):
            name = f.stem.lower()
            try:
                raw = f.read_text()
            except Exception:
                continue
            # Parse optional YAML-ish frontmatter (--- ... ---)
            meta = {}
            template = raw
            if raw.startswith("---"):
                parts = raw.split("---", 2)
                if len(parts) >= 3:
                    fm, template = parts[1], parts[2].strip()
                    for line in fm.splitlines():
                        if ":" in line:
                            k, _, v = line.partition(":")
                            meta[k.strip().lower()] = v.strip()
            commands[name] = {
                "template":    template,
                "description": meta.get("description", f"Custom command: {name}"),
                "agent":       meta.get("agent", ""),
                "model":       meta.get("model", ""),
                "subtask":     meta.get("subtask", "").lower() == "true",
                "file":        str(f),
            }
    return commands

# Global undo stack  [{path: str, before: str|None, after: str}]
_undo_stack: list = []
_redo_stack: list = []

# ── File cache ────────────────────────────────────────────────────────────────
# Lưu nội dung + symbol map của file đã đọc/ghi trong session.
# AI thấy cache trong system prompt → không cần read lại file đã biết.
# Cache tự update sau mỗi write/edit → không bao giờ stale.
_file_cache: dict = {}  # {abs_path: {"content": str, "symbols": dict, "mtime": float, "access": float}}

# ── Bug 1 fix: LRU limits ─────────────────────────────────────────────────────
CACHE_MAX_FILES  = 6      # tối đa N file trong cache block (LRU — file cũ nhất bị drop khỏi prompt)
CACHE_MAX_CHARS  = 5_000  # tổng ký tự inject vào system prompt, không vượt quá

# ── Memory pressure eviction ──────────────────────────────────────────────────
# Evict _file_cache entries khi RAM cao để tránh OOM trên Android.
# Ngưỡng: soft=50%, hard=65%, critical=80% tổng RAM.
# Kích hoạt sau mỗi batch tool calls từ agent_turn().
_MEM_SOFT     = float(os.environ.get("FW_MEM_SOFT",     "0.50"))
_MEM_HARD     = float(os.environ.get("FW_MEM_HARD",     "0.65"))
_MEM_CRITICAL = float(os.environ.get("FW_MEM_CRITICAL", "0.80"))
_MEM_COOLDOWN = 5.0   # giây giữa 2 lần evict liên tiếp
_mem_last_evict: float = 0.0

def _mem_ratio() -> float:
    """RSS hiện tại / total RAM. Trả về 0.0 nếu không đọc được.
    Dùng /proc/self/status (VmRSS) thay vì ru_maxrss để lấy RSS thực tại,
    không phải peak — tránh evict cache quá sớm trên Android/Termux.
    """
    try:
        # Ưu tiên /proc/self/status (Linux/Android/Termux) — RSS thực tại
        rss_kb = 0
        with open("/proc/self/status") as _f:
            for _line in _f:
                if _line.startswith("VmRSS:"):
                    rss_kb = int(_line.split()[1])
                    break
        if rss_kb > 0:
            total = os.sysconf("SC_PAGE_SIZE") * os.sysconf("SC_PHYS_PAGES")
            return (rss_kb * 1024) / total if total > 0 else 0.0
    except Exception:
        pass
    # Fallback: ru_maxrss (macOS hoặc hệ thống không có /proc)
    try:
        import resource as _res
        rss   = _res.getrusage(_res.RUSAGE_SELF).ru_maxrss
        rss_bytes = rss * 1024 if sys.platform != "darwin" else rss
        total = os.sysconf("SC_PAGE_SIZE") * os.sysconf("SC_PHYS_PAGES")
        return rss_bytes / total if total > 0 else 0.0
    except Exception:
        return 0.0

def memory_pressure_evict() -> None:
    """
    Evict _file_cache theo mức RAM:
    - soft  (≥50%): xóa entry không access trong 60 phút.
    - hard  (≥65%): xóa entry không access trong 30 phút.
    - critical (≥80%): clear toàn bộ cache.
    Có cooldown 5s để không spam khi nhiều tool calls liên tiếp.
    """
    global _mem_last_evict
    if not _file_cache:
        return
    now = time.time()
    if now - _mem_last_evict < _MEM_COOLDOWN:
        return
    ratio = _mem_ratio()
    if ratio < _MEM_SOFT:
        return
    _mem_last_evict = now
    if ratio >= _MEM_CRITICAL:
        _file_cache.clear()
        if _cache_debug:
            print(f"  {RED}[cache mem]{R} critical ({ratio:.0%}) → clear all")
        return
    cutoff_min = 30 if ratio >= _MEM_HARD else 60
    cutoff_ts  = now - cutoff_min * 60
    stale = [k for k, v in _file_cache.items() if v.get("access", 0) < cutoff_ts]
    for k in stale:
        _file_cache.pop(k, None)
    if stale and _cache_debug:
        level = "hard" if ratio >= _MEM_HARD else "soft"
        print(f"  {YELLOW}[cache mem]{R} {level} ({ratio:.0%}) → evict {len(stale)} entries")

# ── Bug 3 fix: symbol parsing mạnh hơn ───────────────────────────────────────
def _parse_symbols(content: str, ext: str = "") -> dict:
    """
    Parse symbols (function/class/variable) từ content.
    Hỗ trợ: Python, JS/TS (kể cả arrow function lồng, destructuring), HTML id/class.
    Trả về {name: {"line": int, "snippet": str}}
    """
    symbols = {}
    lines   = content.splitlines()

    # HTML: tìm id= và các tag có ý nghĩa (button, input, form, div có id)
    if ext in (".html", ".htm"):
        for i, line in enumerate(lines, 1):
            # id="foo" hoặc id='foo'
            for m in re.finditer(r'\bid=["\'](\w[\w\-]*)["\']', line):
                name = m.group(1)
                symbols[f"#{name}"] = {"line": i, "snippet": line.strip()[:70]}
            # class="foo bar" — lấy từng class
            for m in re.finditer(r'\bclass=["\']([^"\']+)["\']', line):
                for cls in m.group(1).split():
                    if cls not in symbols:
                        symbols[f".{cls}"] = {"line": i, "snippet": line.strip()[:70]}
        return symbols

    for i, line in enumerate(lines, 1):
        stripped = line.strip()
        if not stripped or stripped.startswith(("//", "#", "/*", "*")):
            continue

        # ── Python ──────────────────────────────────────────────────────────
        m = re.match(r'^(async\s+)?def\s+(\w+)\s*[\(:]', stripped)
        if m:
            symbols[m.group(2)] = {"line": i, "snippet": stripped[:70]}
            continue
        m = re.match(r'^class\s+(\w+)', stripped)
        if m:
            symbols[m.group(1)] = {"line": i, "snippet": stripped[:70]}
            continue

        # ── JS/TS: named function declaration ────────────────────────────────
        m = re.match(r'^(?:export\s+)?(?:default\s+)?(?:async\s+)?function\s*\*?\s*(\w+)\s*[\(<]', stripped)
        if m:
            symbols[m.group(1)] = {"line": i, "snippet": stripped[:70]}
            continue

        # ── JS/TS: class ─────────────────────────────────────────────────────
        m = re.match(r'^(?:export\s+)?(?:default\s+)?class\s+(\w+)', stripped)
        if m:
            symbols[m.group(1)] = {"line": i, "snippet": stripped[:70]}
            continue

        # ── JS/TS: const/let/var foo = ... (arrow, function, value) ─────────
        # Bắt cả: const foo = () => / const foo = async () => / const foo = function
        m = re.match(r'^(?:export\s+)?(?:const|let|var)\s+(\w+)\s*=\s*(?:async\s+)?(?:\(|function|\w+\s*=>)', stripped)
        if m:
            symbols[m.group(1)] = {"line": i, "snippet": stripped[:70]}
            continue

        # ── JS/TS: destructuring: const { foo, bar } = ... ──────────────────
        m = re.match(r'^(?:export\s+)?(?:const|let|var)\s*\{([^}]+)\}\s*=', stripped)
        if m:
            for name in re.findall(r'\b(\w+)\b', m.group(1)):
                if name not in ("default",):
                    symbols[name] = {"line": i, "snippet": stripped[:70]}
            continue

        # ── JS/TS: object method shorthand: foo() { / async foo() { ─────────
        m = re.match(r'^(?:async\s+)?(\w+)\s*\([^)]*\)\s*\{', stripped)
        if m and m.group(1) not in ("if", "for", "while", "switch", "catch"):
            symbols[m.group(1)] = {"line": i, "snippet": stripped[:70]}
            continue

        # ── JS/TS: module.exports.foo = / exports.foo = ──────────────────────
        m = re.match(r'^(?:module\.)?exports\.(\w+)\s*=', stripped)
        if m:
            symbols[m.group(1)] = {"line": i, "snippet": stripped[:70]}
            continue

        # ── CSS: selector (chỉ parse .fw và #fw-style selectors) ────────────
        if ext in (".css", ".scss", ".sass", ".less"):
            m = re.match(r'^([.#][\w\-]+(?:\s*,\s*[.#][\w\-]+)*)\s*\{', stripped)
            if m:
                for sel in m.group(1).split(","):
                    sel = sel.strip()
                    if sel:
                        symbols[sel] = {"line": i, "snippet": stripped[:70]}
                continue

    return symbols

# Debug mode — bật bằng env FW_CACHE_DEBUG=1 hoặc /cache debug on
_cache_debug: bool = os.environ.get("FW_CACHE_DEBUG", "").strip() == "1"

def _cache_log(op: str, path: str, extra: str = ""):
    """In log cache nếu debug mode bật. op: '+' add, '-' drop, '~' update, '?' stale"""
    if not _cache_debug:
        return
    rel = path
    try:
        rel = str(Path(path).resolve().relative_to(_workspace_root()))
    except ValueError:
        try:
            rel = str(Path(path).relative_to(Path.cwd()))
        except ValueError:
            pass
    icons = {"+": GREEN, "-": RED, "~": YELLOW, "?": CYAN}
    color = icons.get(op, DIM)
    extra_str = f"  {DIM}{extra}{R}" if extra else ""
    print(f"  {color}[cache {op}]{R} {DIM}{rel}{R}{extra_str}")

def _content_hash(content: str) -> str:
    """
    Hash content để detect thay đổi chính xác hơn mtime.
    File nhỏ (< 50KB): hash full. File lớn: sample first+last 4KB.
    """
    import hashlib
    sample = content[:4096] + content[-4096:] if len(content) > 50_000 else content
    return hashlib.md5(sample.encode(errors="replace")).hexdigest()[:12]

def _cache_put(path: str, content: str, sid: str = ""):
    """Lưu file vào cache sau khi đọc hoặc ghi. Cập nhật access time cho LRU."""
    sid = sid or _project_dir_sid or ""
    p   = Path(path).expanduser().resolve()
    ext = p.suffix.lower()
    now = time.time()
    key = str(p)
    op  = "~" if key in _file_cache else "+"
    # Dùng mtime thực từ disk thay vì time.time() — tránh clock skew giữa
    # Python process time và filesystem time (Android FAT32, network FS, Termux).
    try:
        disk_mtime = p.stat().st_mtime
    except Exception:
        disk_mtime = now
    _file_cache[key] = {
        "content": content,
        "symbols": _parse_symbols(content, ext),
        "mtime":   disk_mtime,
        "access":  now,
        "hash":    _content_hash(content),  # hash check — chính xác hơn mtime trên Android
    }
    _cache_log(op, key, f"{len(content)} chars  hash={_file_cache[key]['hash']}")
    if sid:
        _index_update(key, content, _file_cache[key]["symbols"])

def _cache_touch(path: str):
    """Cập nhật access time khi file được dùng (LRU)."""
    key = str(Path(path).expanduser().resolve())
    if key in _file_cache:
        _file_cache[key]["access"] = time.time()
        _cache_log("~", key, "touch")

def _cache_invalidate(path: str):
    """
    Xoá cache khi file bị xoá hoặc external-modified.
    Hash check: đọc content thật → so hash — chính xác hơn mtime trên Termux/Android.

    BUG FIX (đã verify bằng test thật, không phải lý thuyết): bản cũ có
    "fast path" skip hash check nếu real_mtime <= cached_mtime + 1, với lý do
    tránh đọc file không cần thiết. Nhưng điều này tạo ra cửa sổ race 1 GIÂY
    TRÊN MỌI FILESYSTEM (không riêng Android FAT32) — nếu process khác/user
    tự sửa file trong vòng 1s sau khi agent write/edit, mtime mới vẫn nằm
    trong ngưỡng "chưa đổi" nên hash check bị bỏ qua hoàn toàn, và tool_read
    sau đó im lặng trả về NỘI DUNG CŨ từ cache dù disk đã khác. Test tái hiện
    được cả khi KHÔNG ép mtime giả tạo, chỉ cần ghi đè file cùng giây.
    Fix: bỏ fast-path, luôn hash-check. Chi phí chấp nhận được vì _content_hash
    đã tự sample 4KB đầu+cuối cho file >50KB, không đọc toàn bộ file lớn.

    BUG FIX #2 (index.json không đồng bộ với _file_cache khi external edit):
    trước đây hàm này chỉ pop _file_cache, không đụng gì tới index.json (đọc
    bởi tool_file_index — lệnh /file_index hoặc "map index" trong CLI/web).
    Hệ quả thực tế: nếu 1 file được tạo/đọc lần đầu lúc nội dung còn rỗng
    hoặc chưa có def/class (ví dụ agent tạo file trống, user tự gõ code sau
    bằng editor khác trên Termux/Android — KHÔNG qua tool_write/tool_edit),
    index.json giữ nguyên "symbols": {} từ lần cache đầu tiên đó MÃI MÃI, dù
    _file_cache đã đúng invalidate. Người dùng thấy mọi file .py trong index
    đều "symbols": {} dù file có def/class thật, vì tool_file_index chỉ đọc
    index.json (không tự parse lại). Fix: khi phát hiện external edit hoặc
    file bị xoá, xoá luôn entry tương ứng khỏi index.json — lần read/write
    kế tiếp trên file đó sẽ tự rebuild symbols đúng qua _cache_put(). Không
    đổi hành vi khi file không có gì thay đổi (nhánh hash khớp bên dưới vẫn
    giữ nguyên, không đụng index).
    """
    key = str(Path(path).expanduser().resolve())
    if key not in _file_cache:
        return
    p = Path(key)
    if not p.exists():
        _cache_log("-", key, "file deleted")
        _file_cache.pop(key, None)
        _index_drop_stale_entry(key)
        return
    try:
        cached_hash  = _file_cache[key].get("hash", "")
        real_mtime   = p.stat().st_mtime

        if not cached_hash:
            # Không có hash để so (cache cũ từ trước khi có field này) —
            # fallback về mtime, an toàn hơn hash rỗng.
            cached_mtime = _file_cache[key]["mtime"]
            if real_mtime > cached_mtime + 1:
                _cache_log("-", key, "mtime changed, no hash to verify")
                _file_cache.pop(key, None)
                _index_drop_stale_entry(key)
            return

        real_content = p.read_text(errors="replace")
        real_hash    = _content_hash(real_content)
        if real_hash == cached_hash:
            # Hash khớp — nội dung thật không đổi, chỉ mtime có thể drift
            # (Android FAT32 resolution thấp, hoặc agent tự write lại y hệt).
            _file_cache[key]["mtime"] = real_mtime
            return

        _cache_log("-", key, f"external edit detected (hash {cached_hash} → {real_hash})")
        _file_cache.pop(key, None)
        _index_drop_stale_entry(key)

    except Exception as e:
        _cache_log("?", key, f"check error: {e}")

def _index_drop_stale_entry(abs_path_key: str):
    """Xoá 1 entry khỏi index.json theo abs path (best-effort, không raise).
    Dùng khi _cache_invalidate() phát hiện file đã đổi/mất từ bên ngoài agent,
    để tool_file_index() không tiếp tục hiển thị symbols cũ/sai của entry đó.
    _index_load/_index_save được định nghĩa ở 06_tools_fs.py (load SAU file
    này) nhưng tra cứu tên global chỉ xảy ra lúc hàm THỰC THI, không phải lúc
    định nghĩa — nên gọi được bình thường, giống các global cross-file khác
    trong project (xem comment đầu fw.py).
    """
    try:
        index = _index_load()
    except Exception:
        return
    stale_rel = None
    for rel, info in index.items():
        try:
            if str(Path(info.get("path", "")).resolve()) == abs_path_key:
                stale_rel = rel
                break
        except Exception:
            continue
    if stale_rel is not None:
        del index[stale_rel]
        _index_save(index)

def _cache_validate_all():
    """Quét toàn cache trước mỗi turn — drop entry nào stale."""
    for key in list(_file_cache.keys()):
        _cache_invalidate(key)

# B5 FIX: _build_cache_block() (inject file content vào user message mỗi turn)
# đã bị xóa — không còn nơi nào gọi nó từ khi agent_turn() chuyển sang giữ
# prefix cache ổn định (xem comment "cache_block bỏ" trong 09_api_system.py,
# agent_turn()). Cơ chế hiện tại: _cache_put()/_cache_touch() cập nhật
# _file_cache ngay sau mỗi write/edit/read, model biết content mới nhất qua
# tool result trả về trực tiếp, không cần block riêng inject vào message.
# CACHE_MAX_FILES/CACHE_MAX_CHARS phía trên vẫn giữ — dùng làm số hiển thị
# tham khảo trong lệnh /cache (xem 10_main.py).

# ── Project dir sandbox ──────────────────────────────────────────────────────
# Stores the project directory for the current session.
# Set once (on first write) and locked for the rest of the session.
_project_dir: Path | None = None
_project_dir_conn = None
_project_dir_sid  = ""
_project_dir_is_placeholder: bool = False  # True khi set là cwd eager-init, chưa tạo subdir thật

def _project_dir_str() -> str:
    """Tra ve full absolute path cua project_dir hien tai.
    Luon dung _project_dir neu co (ke ca placeholder) — dam bao cache key
    on dinh tu turn 0, khong doi sau write dau tien."""
    if _project_dir is not None:
        return str(_project_dir.resolve())
    return str(Path.cwd().resolve())

def _sandbox_init(conn, sid, project_dir_str: str | None):
    """Called at session start to restore or reset the sandbox.
    project_dir luôn có sẵn từ session_create() — path ổn định suốt session."""
    global _project_dir, _project_dir_conn, _project_dir_sid
    _project_dir_conn = conn
    _project_dir_sid  = sid
    if project_dir_str:
        _project_dir = Path(project_dir_str).resolve()
        _project_dir.mkdir(parents=True, exist_ok=True)
    else:
        proj = (Path.cwd().resolve() / sid).resolve()
        proj.mkdir(parents=True, exist_ok=True)
        _project_dir = proj
        if conn:
            session_update(conn, sid, project_dir=str(proj))

def _ensure_project_dir(requested_path: str = "") -> Path:
    """Trả về project_dir của session hiện tại (tạo nếu chưa có)."""
    global _project_dir
    if _project_dir is not None:
        return _project_dir

    sid = _project_dir_sid or "project"
    proj = (Path.cwd().resolve() / sid).resolve()
    proj.mkdir(parents=True, exist_ok=True)
    _project_dir = proj
    if _project_dir_conn and _project_dir_sid:
        session_update(_project_dir_conn, _project_dir_sid, project_dir=str(proj))
    return proj

def _resolve_read_path(path: str | Path) -> Path:
    """
    Resolve path cho các tool đọc (read, view_symbol, verify, lsp, extract src).
    Quy tắc nghiêm ngặt:
    1. Nếu rỗng -> trả về project_dir (hoặc cwd nếu chưa có session).
    2. Nếu là absolute -> resolve trực tiếp (sẽ qua _check_sandbox_read kiểm tra).
    3. Nếu là relative có prefix proj.name (vd '9aa25482/01_ui.py') -> strip prefix và map vào project_dir.
    4. Mọi relative path khác -> LUÔN resolve từ project_dir (project_dir / path).
    Không fallback sang Path.cwd() để triệt tiêu 100% nguy cơ bất đồng bộ workspace root.
    """
    if not path:
        return _project_dir.resolve() if _project_dir is not None else Path.cwd().resolve()
    p_orig = Path(path).expanduser()
    proj = _project_dir.resolve() if _project_dir is not None else Path.cwd().resolve()

    if p_orig.is_absolute():
        return p_orig.resolve()

    # Kiểm tra xem có bị prefix tên project_dir không (vd "9aa25482/foo.py")
    if p_orig.parts and p_orig.parts[0] == proj.name:
        stripped = Path(*p_orig.parts[1:]) if len(p_orig.parts) > 1 else Path(".")
        return (proj / stripped).resolve()

    # Luôn resolve từ project_dir duy nhất
    return (proj / p_orig).resolve()


def _resolve_to_sandbox(path: str) -> Path:
    """
    Tự động redirect path vào project_dir (tạo nếu chưa có).
    - Nếu path đã nằm trong project_dir → giữ nguyên.
    - Nếu path bắt đầu bằng proj.name (vd '9aa25482/01_ui.py') → strip để tránh double nesting.
    - Nếu path là relative hoặc nằm ngoài → rewrite vào project_dir,
      giữ lại cấu trúc thư mục con tương đối nếu có.
    Dùng chung cho write / edit / multiedit / apply_patch / delete / extract dst.
    """
    proj = _ensure_project_dir(path)
    p_orig = Path(path).expanduser()

    # Đã nằm trong project_dir rồi → không đổi
    try:
        p_orig.resolve().relative_to(proj.resolve())
        return p_orig.resolve()
    except ValueError:
        pass

    # Nếu path bắt đầu bằng tên của proj (vd '9aa25482/01_ui.py') → strip để tránh double nesting
    if not p_orig.is_absolute():
        parts = p_orig.parts
        if parts and parts[0] == proj.name:
            stripped = Path(*parts[1:]) if len(parts) > 1 else Path(".")
            return (proj / stripped).resolve()

    # Nằm trong cwd nhưng ngoài project_dir → giữ relative path từ cwd
    try:
        rel = p_orig.resolve().relative_to(Path.cwd().resolve())
        if rel.parts and rel.parts[0] == proj.name:
            rel = Path(*rel.parts[1:]) if len(rel.parts) > 1 else Path(".")
    except ValueError:
        # Absolute hoàn toàn ngoài cwd → chỉ lấy phần tên file/subpath
        rel = Path(*p_orig.parts[1:]) if p_orig.is_absolute() else Path(p_orig.name)

    return (proj / rel).resolve()

# ════════════════════════════════════════════════════════════════════════════
# DATABASE
# ════════════════════════════════════════════════════════════════════════════

def db_connect():
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(str(DB_PATH))
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys=ON")
    conn.executescript("""
        CREATE TABLE IF NOT EXISTS session (
            id           TEXT PRIMARY KEY,
            title        TEXT NOT NULL,
            directory    TEXT NOT NULL,
            model        TEXT NOT NULL,
            agent        TEXT NOT NULL DEFAULT 'build',
            created_at   INTEGER NOT NULL,
            updated_at   INTEGER NOT NULL,
            token_input  INTEGER DEFAULT 0,
            token_output INTEGER DEFAULT 0,
            token_cached INTEGER DEFAULT 0,
            project_dir  TEXT,
            provider     TEXT DEFAULT ''
        );
        CREATE TABLE IF NOT EXISTS message (
            id          TEXT PRIMARY KEY,
            session_id  TEXT NOT NULL REFERENCES session(id) ON DELETE CASCADE,
            role        TEXT NOT NULL,
            content     TEXT NOT NULL,
            created_at  INTEGER NOT NULL
        );
        CREATE TABLE IF NOT EXISTS todo (
            id          TEXT PRIMARY KEY,
            session_id  TEXT NOT NULL REFERENCES session(id) ON DELETE CASCADE,
            content     TEXT NOT NULL,
            status      TEXT NOT NULL DEFAULT 'pending',
            priority    TEXT NOT NULL DEFAULT 'medium',
            updated_at  INTEGER NOT NULL
        );
        CREATE TABLE IF NOT EXISTS file_snapshot (
            id          TEXT PRIMARY KEY,
            session_id  TEXT NOT NULL REFERENCES session(id) ON DELETE CASCADE,
            path        TEXT NOT NULL,
            before      TEXT,
            after       TEXT,
            created_at  INTEGER NOT NULL,
            undone      INTEGER NOT NULL DEFAULT 0
        );
        CREATE TABLE IF NOT EXISTS checkpoint (
            id          TEXT PRIMARY KEY,
            session_id  TEXT NOT NULL REFERENCES session(id) ON DELETE CASCADE,
            label       TEXT NOT NULL,
            summary     TEXT NOT NULL,
            created_at  INTEGER NOT NULL
        );
        -- Migration: add agent column if missing
        CREATE TABLE IF NOT EXISTS _meta (key TEXT PRIMARY KEY, value TEXT);
    """)
    # Migration: add project_dir column if missing (older DBs)
    cols = [r[1] for r in conn.execute("PRAGMA table_info(session)").fetchall()]
    if "project_dir" not in cols:
        conn.execute("ALTER TABLE session ADD COLUMN project_dir TEXT")
        conn.commit()
    if "token_cached" not in cols:
        conn.execute("ALTER TABLE session ADD COLUMN token_cached INTEGER DEFAULT 0")
        conn.commit()
    if "provider" not in cols:
        conn.execute("ALTER TABLE session ADD COLUMN provider TEXT DEFAULT ''")
        conn.commit()
    snapshot_cols = [r[1] for r in conn.execute(
        "PRAGMA table_info(file_snapshot)").fetchall()]
    if "undone" not in snapshot_cols:
        conn.execute(
            "ALTER TABLE file_snapshot ADD COLUMN undone INTEGER NOT NULL DEFAULT 0")
        conn.commit()
    # Migration: DB cũ có thể đã tạo file_snapshot với `after TEXT NOT NULL`
    # (bug gốc). tool_delete() cần ghi after=NULL để đánh dấu "sau khi xoá
    # thì không còn nội dung" — SQLite chặn insert NULL vào cột NOT NULL nên
    # trước đây delete crash với IntegrityError. SQLite không hỗ trợ
    # ALTER COLUMN để bỏ NOT NULL trực tiếp, nên phải rebuild bảng qua bảng
    # tạm khi phát hiện constraint cũ.
    after_info = next((r for r in conn.execute(
        "PRAGMA table_info(file_snapshot)").fetchall() if r[1] == "after"), None)
    if after_info is not None and after_info[3] == 1:  # notnull flag == 1
        conn.executescript("""
            CREATE TABLE file_snapshot_new (
                id          TEXT PRIMARY KEY,
                session_id  TEXT NOT NULL REFERENCES session(id) ON DELETE CASCADE,
                path        TEXT NOT NULL,
                before      TEXT,
                after       TEXT,
                created_at  INTEGER NOT NULL,
                undone      INTEGER NOT NULL DEFAULT 0
            );
            INSERT INTO file_snapshot_new
                (id, session_id, path, before, after, created_at, undone)
                SELECT id, session_id, path, before, after, created_at, undone
                FROM file_snapshot;
            DROP TABLE file_snapshot;
            ALTER TABLE file_snapshot_new RENAME TO file_snapshot;
        """)
        conn.commit()
    conn.commit()
    return conn

def session_create(conn, model, title="", agent=AGENT_BUILD):
    sid = str(uuid.uuid4())[:8]
    now = int(time.time())
    if not title:
        title = f"Session {datetime.fromtimestamp(now).strftime('%m-%d %H:%M')}"

    # Tạo thư mục sandbox ngay — full absolute path, stable suốt session cho cache.
    # is_placeholder=True: path đã có nhưng tools_fs chưa enforce sandbox read
    # cho đến khi AI write file đầu tiên (giữ nguyên hành vi đọc project có sẵn).
    project_dir = Path.cwd().resolve() / sid
    project_dir.mkdir(parents=True, exist_ok=True)
    project_dir_str = str(project_dir)

    conn.execute("""
        INSERT INTO session
            (id,title,directory,model,agent,created_at,updated_at,
             token_input,token_output,token_cached,project_dir,provider)
        VALUES (?,?,?,?,?,?,?,0,0,0,?,?)
    """, (sid, title, os.getcwd(), model, agent, now, now,
          project_dir_str, _active_provider))
    conn.commit()
    return {"id": sid, "title": title, "directory": os.getcwd(),
            "model": model, "agent": agent, "project_dir": project_dir_str,
            "provider": _active_provider}

def session_list(conn):
    return [dict(r) for r in conn.execute(
        "SELECT * FROM session ORDER BY updated_at DESC LIMIT 20").fetchall()]

def session_update(conn, sid, **kw):
    kw["updated_at"] = int(time.time())
    sets = ", ".join(f"{k}=?" for k in kw)
    conn.execute(f"UPDATE session SET {sets} WHERE id=?", (*kw.values(), sid))
    conn.commit()

def _normalize_message(role, raw):
    """
    Convert any stored message to OpenAI/Fireworks wire format.
    Handles old Anthropic-format assistant messages that have list content
    with type:tool_use blocks.
    """
    # If content is a plain string, wrap as-is
    if isinstance(raw, str):
        return {"role": role, "content": raw}

    # If it's already an OpenAI-style assistant msg with tool_calls key
    if isinstance(raw, dict) and "tool_calls" in raw:
        return raw  # already correct

    # If content is a list (possible Anthropic format or mixed)
    if isinstance(raw, list):
        # Check for Anthropic tool_use blocks
        tool_use_blocks = [b for b in raw if isinstance(b, dict) and b.get("type") == "tool_use"]
        text_blocks     = [b for b in raw if isinstance(b, dict) and b.get("type") == "text"]
        if tool_use_blocks and role == "assistant":
            # Convert to OpenAI format
            text_content = text_blocks[0]["text"] if text_blocks else None
            tool_calls = [{
                "id":       b["id"],
                "type":     "function",
                "function": {
                    "name":      b["name"],
                    "arguments": json.dumps(b.get("input", {}), ensure_ascii=False)
                }
            } for b in tool_use_blocks]
            return {"role": "assistant", "content": text_content, "tool_calls": tool_calls}
        # Plain list content (e.g. multi-part user message) — keep as-is
        # but Fireworks only accepts string content for most roles, so flatten
        text = " ".join(b.get("text", "") for b in raw if isinstance(b, dict))
        return {"role": role, "content": text or str(raw)}

    # Tool result stored as dict {role, tool_call_id, content}
    if isinstance(raw, dict):
        if role == "tool" and "tool_call_id" in raw:
            return raw  # already correct wire format
        return {"role": role, "content": raw.get("content", str(raw))}

    return {"role": role, "content": str(raw)}

def messages_load(conn, sid):
    rows = conn.execute(
        "SELECT role,content FROM message WHERE session_id=? ORDER BY created_at, rowid",
        (sid,)).fetchall()
    result = []
    for r in rows:
        try:
            raw = json.loads(r["content"])
        except (json.JSONDecodeError, TypeError):
            # DB row corrupt — skip thay vì crash toàn app khi resume session
            continue
        msg = _normalize_message(r["role"], raw)
        result.append(msg)
    return result

def message_save(conn, sid, role, content):
    conn.execute("INSERT INTO message VALUES (?,?,?,?,?)",
                 (str(uuid.uuid4()), sid, role,
                  json.dumps(content, ensure_ascii=False), int(time.time())))
    conn.execute("UPDATE session SET updated_at=? WHERE id=?", (int(time.time()), sid))
    conn.commit()

def checkpoint_save(conn, sid, label: str, messages: list | None = None,
                    summary: str = "") -> str:
    """Persist a progress marker without injecting it into model context."""
    now = int(time.time())
    label = (label or "checkpoint").strip()[:80]
    if not summary and messages:
        user_count = sum(1 for m in messages if m.get("role") == "user")
        assistant_count = sum(1 for m in messages if m.get("role") == "assistant")
        tool_count = sum(1 for m in messages if m.get("role") == "tool")
        summary = f"{user_count} user, {assistant_count} assistant, {tool_count} tool messages"
    summary = (summary or "manual checkpoint").strip()[:500]
    cid = str(uuid.uuid4())[:8]
    conn.execute("INSERT INTO checkpoint VALUES (?,?,?,?,?)",
                 (cid, sid, label, summary, now))
    conn.execute("UPDATE session SET updated_at=? WHERE id=?", (now, sid))
    conn.commit()
    return cid

def checkpoints_load(conn, sid, limit: int = 10) -> list[dict]:
    rows = conn.execute(
        "SELECT * FROM checkpoint WHERE session_id=? ORDER BY created_at DESC LIMIT ?",
        (sid, int(limit))
    ).fetchall()
    return [dict(r) for r in rows]

# Ảnh (content dạng list [{"type":"text",...},{"type":"image_url",...}])
# không bao giờ được lưu xuống DB — chỉ sống trong RAM (state.messages),
# theo đúng thiết kế ở 10_main.py (message_save luôn nhận text thuần).
# FIX: messages_replace_all() là điểm ghi DB DUY NHẤT nhận messages nguyên
# dạng (không qua message_save) — được gọi từ maybe_compact() (compact tự
# động, "recent" giữ lại có thể chứa turn ảnh vừa gửi) và /compact thủ công
# (10_main.py). Cả 2 đường trước đây ghi thẳng content list (kèm base64)
# xuống DB nếu ảnh nằm trong phần message được giữ lại — vi phạm thiết kế
# trên. Strip mọi block ảnh thành placeholder text TRƯỚC khi ghi, không đụng
# gì tới bản messages trong RAM (hàm chỉ đọc, không sửa list truyền vào).
def _strip_images_for_storage(content):
    """content có thể là str (giữ nguyên) hoặc list block kiểu OpenAI
    multimodal. Trả về str an toàn để lưu DB — text gốc + placeholder cho
    mỗi ảnh, không bao giờ chứa base64."""
    if not isinstance(content, list):
        return content
    texts = [b.get("text", "") for b in content
             if isinstance(b, dict) and b.get("type") == "text"]
    n_img = sum(1 for b in content
                if isinstance(b, dict) and b.get("type") == "image_url")
    text = " ".join(t for t in texts if t).strip()
    if n_img:
        suffix = "[đã gửi 1 ảnh]" if n_img == 1 else f"[đã gửi {n_img} ảnh]"
        text = f"{text} {suffix}".strip() if text else suffix
    return text

def messages_replace_all(conn, sid, messages):
    conn.execute("DELETE FROM message WHERE session_id=?", (sid,))
    ts = int(time.time())
    for i, m in enumerate(messages):
        stored = m if isinstance(m, dict) else {"role": "user", "content": str(m)}
        if stored.get("role") == "user" and isinstance(stored.get("content"), list):
            stored = {**stored, "content": _strip_images_for_storage(stored["content"])}
        conn.execute("INSERT INTO message VALUES (?,?,?,?,?)",
                     (str(uuid.uuid4()), sid, stored["role"],
                      json.dumps(stored, ensure_ascii=False), ts + i))
    conn.commit()
